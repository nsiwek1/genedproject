#!/usr/bin/env python3
"""
LoRA fine-tuning script for Confucius/Mencius datasets.

Usage:
    python3 scripts/train_lora.py \
        --base-model meta-llama/Llama-3.2-3B-Instruct \
        --confucius-data data/instruction_pairs/confucius_auto.jsonl \
        --mencius-data data/instruction_pairs/mencius_auto.jsonl \
        --output models/confucius-mencius-lora
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import List

from datasets import load_dataset, Dataset
from transformers import AutoTokenizer, AutoModelForCausalLM, TrainingArguments
from peft import LoraConfig, get_peft_model, TaskType
from trl import SFTTrainer


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Fine-tune Llama with LoRA for Confucius/Mencius personas.")
    parser.add_argument("--base-model", type=str, required=True, help="Base causal LM checkpoint (e.g., meta-llama/Llama-3.2-3B-Instruct).")
    parser.add_argument("--confucius-data", type=Path, required=True, help="JSONL file with Confucius instruction pairs.")
    parser.add_argument("--mencius-data", type=Path, required=True, help="JSONL file with Mencius instruction pairs.")
    parser.add_argument("--output", type=Path, required=True, help="Directory to save adapter weights.")
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--grad-accum", type=int, default=8)
    parser.add_argument("--lr", type=float, default=2e-4)
    parser.add_argument("--max-seq-len", type=int, default=1024)
    return parser.parse_args()


def load_and_prepare_dataset(paths: List[Path]) -> Dataset:
    data_files = [str(p) for p in paths]
    ds = load_dataset("json", data_files=data_files, split="train")

    def format_row(row):
        philosopher = row["philosopher"]
        tag = f"[{philosopher}] "
        user = row["messages"][1]["content"]
        assistant = row["messages"][2]["content"]
        return {"text": tag + user + "\n\n" + assistant}

    return ds.map(format_row)


def main():
    args = parse_args()

    dataset = load_and_prepare_dataset([args.confucius_data, args.mencius_data])

    tokenizer = AutoTokenizer.from_pretrained(args.base_model)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        args.base_model,
        load_in_8bit=True,
        device_map="auto",
    )

    lora_cfg = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        r=64,
        lora_alpha=128,
        lora_dropout=0.1,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
    )
    model = get_peft_model(model, lora_cfg)

    training_args = TrainingArguments(
        output_dir=str(args.output),
        num_train_epochs=args.epochs,
        per_device_train_batch_size=args.batch_size,
        gradient_accumulation_steps=args.grad_accum,
        learning_rate=args.lr,
        logging_steps=50,
        save_steps=500,
        fp16=True,
    )

    trainer = SFTTrainer(
        model=model,
        tokenizer=tokenizer,
        train_dataset=dataset,
        dataset_text_field="text",
        args=training_args,
        max_seq_length=args.max_seq_len,
    )

    trainer.train()
    model.save_pretrained(args.output)
    tokenizer.save_pretrained(args.output)


if __name__ == "__main__":
    main()

